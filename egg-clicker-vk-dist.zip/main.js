// Заглушка сборки игры
document.getElementById('root').innerHTML = '<h1>VK Egg Clicker 🥚</h1><p>Сборка для загрузки в VK Mini Apps</p>';